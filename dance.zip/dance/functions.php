<?php
/**
 * Dance theme functions and definitions
 */
$myvar = array('hi');
if (!function_exists('dance_setup')) :
    function dance_setup()
    {
        /******* 
         * add theme support
         *******/

        //featured image
        add_theme_support('post-thumbnails');

        //custom logo
        add_theme_support('custom-logo', array(
            'height'      => 250,
            'width'       => 250
        ));

        //register menus
        register_nav_menus(array(
            'primary-menu' => __('Primary'),
            'footer-menu' => __('Footer'),
            'social-menu' => __('Social')
        ));

        //set the permalink structure
        global $wp_rewrite;
        $wp_rewrite->set_permalink_structure( '/%postname%/' );
    }
endif;
add_action('after_setup_theme', 'dance_setup');


if (!function_exists('dance_enqueue_scripts')) :
    function dance_enqueue_scripts()
    {
        //enqueue styles
        wp_enqueue_style('dance-style', get_stylesheet_uri());
        wp_enqueue_style('dance-nav-style', get_template_directory_uri() . '/assets/css/nav.css');

        //enqueue scripts
        wp_enqueue_script('dance-main', get_template_directory_uri() . '/assets/js/main.js');
    }
endif;
add_action('wp_enqueue_scripts', 'dance_enqueue_scripts');

if (!function_exists('dance_widgets_init')) :
    function dance_widgets_init()
    {
        // global $myvar;
        // var_dump($myvar);
        // die();
        register_sidebar(array(
            'name'          => __( 'Sidebar', 'theme_text_domain' ),
            'id'            => 'sidebar-1',
            'description'   => 'Add widgets here'
        ));
    }
endif;
add_action('widgets_init', 'dance_widgets_init');

if (!function_exists('dance_create_post_types')) :
    function dance_create_post_types()
    {
        register_post_type(
            'dance_lesson',
            array('labels' => array(
                'name' => __('Lessons'),
                'singular_name' => __('Lesson')
            ),
            'public' => true,
            'has_archive' => true,
            'menu_position' => 5,
            'supports' => array('title', 'editor', 'thumbnail')
        )
        );
    }
endif;
add_action('init', 'dance_create_post_types');