<?php get_header(); ?>
<h1>Contact</h1>
<p>This is the contact page</p>
<?php
get_template_part('template-parts/content');
get_footer(); ?>