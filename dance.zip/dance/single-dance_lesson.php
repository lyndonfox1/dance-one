<?php get_header(); ?>
<h1>Test single lesson</h1>
<?php
get_template_part('template-parts/content-single');
get_sidebar();
get_footer(); ?>